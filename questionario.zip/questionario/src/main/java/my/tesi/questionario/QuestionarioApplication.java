package my.tesi.questionario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestionarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuestionarioApplication.class, args);
	}

}
